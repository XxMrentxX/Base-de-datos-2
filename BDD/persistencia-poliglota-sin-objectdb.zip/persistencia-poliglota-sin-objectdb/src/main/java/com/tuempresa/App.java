package com.tuempresa;

import com.tuempresa.db.*;

public class App {
    public static void main(String[] args) {
        MongoConnector.test();
        RedisConnector.test();
        Neo4jConnector.test();
        CassandraConnector.test();
    }
}