package com.tuempresa.db;
import com.mongodb.client.*;
import org.bson.Document;

public class MongoConnector {
    public static void test() {
        try (MongoClient client = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase db = client.getDatabase("testdb");
            db.getCollection("productos").insertOne(new Document("nombre", "Zapatilla"));
            System.out.println("MongoDB: Conexión exitosa");
        } catch (Exception e) {
            System.out.println("MongoDB: Error de conexión - " + e.getMessage());
        }
    }
}