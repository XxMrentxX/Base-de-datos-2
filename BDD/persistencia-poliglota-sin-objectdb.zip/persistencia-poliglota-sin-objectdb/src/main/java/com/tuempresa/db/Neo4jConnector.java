package com.tuempresa.db;
import org.neo4j.driver.*;

public class Neo4jConnector {
    public static void test() {
        try (Driver driver = GraphDatabase.driver("bolt://localhost:7687", AuthTokens.basic("neo4j", "test"));
             Session session = driver.session()) {
            session.run("RETURN 1");
            System.out.println("Neo4j: Conexión exitosa");
        } catch (Exception e) {
            System.out.println("Neo4j: Error de conexión - " + e.getMessage());
        }
    }
}