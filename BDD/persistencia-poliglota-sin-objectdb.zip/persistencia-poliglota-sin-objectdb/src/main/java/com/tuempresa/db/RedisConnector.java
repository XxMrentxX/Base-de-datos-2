package com.tuempresa.db;
import redis.clients.jedis.Jedis;

public class RedisConnector {
    public static void test() {
        try (Jedis jedis = new Jedis("localhost", 6379)) {
            jedis.set("test", "funciona!");
            System.out.println("Redis: " + jedis.get("test"));
        } catch (Exception e) {
            System.out.println("Redis: Error de conexión - " + e.getMessage());
        }
    }
}